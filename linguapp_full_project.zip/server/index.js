const express = require('express');
const fetch = require('node-fetch');
const app = express();
app.use(express.json());
const AI_KEY = process.env.GENERATIVE_API_KEY;

app.post('/generate-story', async (req, res) => {
  const { language, ageGroup, interest, topic } = req.body;
  if (!AI_KEY) return res.status(500).json({ error: 'AI key not configured' });
  const prompt = `You are Echo, a safe educational storyteller. Create a short ${language} story for ${ageGroup} on ${topic}. Keep it child-safe.`;
  try {
    const r = await fetch('https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash-preview-09-2025:generateContent?key=' + AI_KEY, {
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body: JSON.stringify({ prompt })
    });
    const j = await r.json();
    res.json(j);
  } catch(e){ res.status(500).json({ error: 'AI request failed', details: String(e) }); }
});

app.post('/generate-convo', async (req,res)=>{
  const { message, language } = req.body;
  if (!AI_KEY) return res.status(500).json({ error: 'AI key not configured' });
  try {
    const r = await fetch('https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash-preview-09-2025:generateContent?key=' + AI_KEY, {
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body: JSON.stringify({ prompt: `Reply in ${language}: ${message}` })
    });
    const j = await r.json();
    res.json(j);
  } catch(e){ res.status(500).json({ error: 'AI request failed' }); }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, ()=>console.log('AI proxy listening on', PORT));
