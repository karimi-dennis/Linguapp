LinguApp - Expo Starter (Full Project)
=====================================

This archive contains a full Expo project scaffold for the Echo language app including:
- Expo React Native front-end
- Firebase client config (Firestore)
- Offline caching utilities
- Kids & Adult UIs
- Lesson flow (words -> phrases -> sentences -> story -> conversation)
- Quiz component
- Ads & RevenueCat skeletons
- Server AI proxy example
- Firestore Admin seeder script

IMPORTANT:
- Do NOT include any secret AI API keys in the mobile app. Use the provided server proxy (server/) and set the environment variable GENERATIVE_API_KEY on the server.
- The Firestore seeder requires a Firebase service account JSON file (NOT included). Place it at scripts/serviceAccount.json before running `npm run seed`.

How to run:
1. Install dependencies: `npm install` (or `yarn`)
2. Fill in your Firebase config in `src/firebaseConfig.js`.
3. Start Expo: `npm start` or `expo start`.
4. To seed Firestore (server-side):
   - Put serviceAccount.json in scripts/
   - Run `node scripts/seedFirestoreAdmin.js`

Server AI proxy:
- A simple Express server is included in server/.
- Deploy it to your provider and set env var GENERATIVE_API_KEY (your AI key).
