import { AdMobRewarded } from 'expo-ads-admob';
export async function showRewardedAd() {
  try {
    await AdMobRewarded.setAdUnitID('ca-app-pub-3940256099942544/5224354917');
    await AdMobRewarded.requestAdAsync();
    await AdMobRewarded.showAdAsync();
  } catch(e){ console.warn('ad failed', e); }
}
