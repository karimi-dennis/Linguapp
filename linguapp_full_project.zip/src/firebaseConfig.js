// src/firebaseConfig.js
import { initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';
import { getStorage } from 'firebase/storage';

// Replace below with your Firebase config (these came from your earlier config)
const firebaseConfig = {
  apiKey: "AIzaSyCECY98k-_4dAi27_DO_0wqpqFRvFLjybk",
  authDomain: "linguapp-c5b5f.firebaseapp.com",
  projectId: "linguapp-c5b5f",
  storageBucket: "linguapp-c5b5f.appspot.com",
  messagingSenderId: "862607016378",
  appId: "1:862607016378:web:0e8af9625bd3bf567f5d83",
  measurementId: "G-6KKR65W0V0"
};

const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app);
export const storage = getStorage(app);
export default app;
