import Purchases from 'react-native-purchases';

export function initRevenueCat() {
  try {
    Purchases.setup('test_qGpHlQaYwudQsxjwkHRFBlXkqlr');
  } catch(e){ console.warn('RevenueCat init failed', e); }
}
export async function getOfferings() {
  try { const o = await Purchases.getOfferings(); return o.current; } catch(e){ return null; }
}
export async function purchasePackage(pkg) { try { return await Purchases.purchasePackage(pkg); } catch(e){ throw e; } }
