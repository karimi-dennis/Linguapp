import AsyncStorage from '@react-native-async-storage/async-storage';
export async function saveLessonOffline(id, data){ await AsyncStorage.setItem(`lesson_${id}`, JSON.stringify(data)); }
export async function loadLessonOffline(id){ const d = await AsyncStorage.getItem(`lesson_${id}`); return d?JSON.parse(d):null; }
