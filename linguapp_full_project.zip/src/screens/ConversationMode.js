import React, {useState} from 'react';
import { View, Text, TextInput, TouchableOpacity, FlatList, StyleSheet } from 'react-native';
import { useProfileStore } from '../store/profileStore';

export default function ConversationMode({ route }) {
  const profile = useProfileStore(s=>s.profile);
  const [messages, setMessages] = useState([{id:'ai-0',text:route.params?.prompt || 'Hi! Tell me about your day.',sender:'ai'}]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);

  async function send() {
    if (!input.trim()) return;
    const userMsg = { id:`u-${Date.now()}`, text: input, sender:'user' };
    setMessages(m => [...m, userMsg]);
    setInput('');
    setLoading(true);
    try {
      const res = await fetch('https://your-ai-proxy.example.com/generate-convo', {
        method:'POST', headers:{'Content-Type':'application/json'},
        body: JSON.stringify({ message: userMsg.text, language: route.params?.language || 'Kiswahili', ageGroup: profile.ageGroup })
      });
      const json = await res.json();
      const ai = json?.text || json?.reply || 'Sorry, could you say that again?';
      setMessages(m => [...m, { id:`ai-${Date.now()}`, text: ai, sender:'ai' }]);
    } catch(e) {
      setMessages(m => [...m, { id:`ai-${Date.now()}`, text: 'Connection error', sender:'ai' }]);
    } finally { setLoading(false); }
  }

  return (
    <View style={{flex:1,padding:12}}>
      <FlatList data={messages} keyExtractor={i=>i.id} renderItem={({item})=>(
        <View style={[styles.msg, item.sender==='user'?styles.user:styles.ai]}><Text>{item.text}</Text></View>
      )} />
      <View style={{flexDirection:'row',alignItems:'center'}}>
        <TextInput value={input} onChangeText={setInput} placeholder='Type...' style={{flex:1,backgroundColor:'#fff',padding:10,borderRadius:8}} />
        <TouchableOpacity onPress={send} style={{backgroundColor:'#005F73',padding:10,borderRadius:8,marginLeft:8}}><Text style={{color:'#fff'}}>Send</Text></TouchableOpacity>
      </View>
    </View>
  );
}

const styles=StyleSheet.create({ msg:{padding:10,borderRadius:10,marginVertical:6,maxWidth:'80%'}, user:{alignSelf:'flex-end',backgroundColor:'#CDEBFF'}, ai:{alignSelf:'flex-start',backgroundColor:'#fff'} });
