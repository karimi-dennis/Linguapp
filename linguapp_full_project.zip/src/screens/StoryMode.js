import React, {useState} from 'react';
import { View, Text, TouchableOpacity, ActivityIndicator, StyleSheet } from 'react-native';
import { useProfileStore } from '../store/profileStore';

export default function StoryMode({ route }) {
  const profile = useProfileStore(s=>s.profile);
  const [story, setStory] = useState(null);
  const [loading, setLoading] = useState(false);

  async function generateStory() {
    setLoading(true);
    try {
      const res = await fetch('https://your-ai-proxy.example.com/generate-story', {
        method:'POST',
        headers:{'Content-Type':'application/json'},
        body: JSON.stringify({ language: route.params?.language || 'Kiswahili', ageGroup: profile.ageGroup, interest: profile.interest, topic: route.params?.topic || 'Animals' })
      });
      const json = await res.json();
      const text = json?.text || json?.result || JSON.stringify(json);
      setStory(text);
    } catch(e){ setStory('Could not generate story.'); }
    setLoading(false);
  }

  return (
    <View style={{flex:1,padding:16}}>
      <Text style={{fontSize:20,fontWeight:'900'}}>Story Mode</Text>
      <TouchableOpacity style={{backgroundColor:'#FFB703',padding:12,borderRadius:10,marginTop:12}} onPress={generateStory}><Text>Generate Story</Text></TouchableOpacity>
      {loading && <ActivityIndicator style={{marginTop:12}} />}
      {story && <View style={{backgroundColor:'#fff',padding:12,borderRadius:10,marginTop:12}}><Text>{story}</Text></View>}
    </View>
  );
}
