import React, {useState} from 'react';
import { View, Text, TouchableOpacity } from 'react-native';

export default function Quiz({ route, navigation }) {
  const questions = route.params?.questions || [{
    prompt: 'What is Jambo?',
    choices: ['Hello','Bye','Thank you'],
    correct: 'Hello'
  }];
  const [index, setIndex] = useState(0);
  const [score, setScore] = useState(0);

  function choose(c) {
    if (c === questions[index].correct) setScore(s => s+1);
    if (index < questions.length - 1) setIndex(i => i+1);
    else navigation.goBack();
  }

  return (
    <View style={{flex:1,padding:12}}>
      <Text style={{fontWeight:'800'}}>{questions[index].prompt}</Text>
      {questions[index].choices.map((c,i)=>(
        <TouchableOpacity key={i} onPress={()=>choose(c)} style={{padding:12,backgroundColor:'#fff',marginTop:8,borderRadius:8}}>
          <Text>{c}</Text>
        </TouchableOpacity>
      ))}
      <Text style={{marginTop:12}}>Score: {score}</Text>
    </View>
  );
}
