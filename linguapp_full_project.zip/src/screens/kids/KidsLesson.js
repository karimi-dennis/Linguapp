import React, { useState, useEffect } from 'react';
import { View, Text, FlatList, TouchableOpacity, StyleSheet, Image, Alert } from 'react-native';
import * as Speech from 'expo-speech';
import { cacheLessonAssets, enqueueProgressUpload, cacheLessonJson, getCachedLesson } from '../../services/offlineSync';
import { fetchLessonById } from '../../services/lessonService';
import { useProfileStore } from '../../store/profileStore';

export default function KidsLesson({ route, navigation }) {
  const lessonId = route.params?.lessonId || route.params?.lesson?.id;
  const profile = useProfileStore(s => s.profile);
  const [lesson, setLesson] = useState(null);
  const [stage, setStage] = useState(0);

  useEffect(() => {
    async function load() {
      let l = await fetchLessonById(lessonId);
      if (!l) {
        l = await getCachedLesson('Kiswahili', lessonId);
      } else {
        await cacheLessonJson('Kiswahili', l);
      }
      setLesson(l);
    }
    load();
  }, [lessonId]);

  if (!lesson) return <View style={{flex:1,justifyContent:'center',alignItems:'center'}}><Text>Loading...</Text></View>;

  const speak = (text) => Speech.speak(text, { language: lesson.language === 'Kiswahili' ? 'sw-KE' : undefined });

  return (
    <View style={{flex:1,padding:16,backgroundColor:'#FFF8E7'}}>
      <Text style={{fontSize:22,fontWeight:'900'}}>{lesson.topic}</Text>
      <Text style={{color:'#666',marginBottom:12}}>Stage: {['Words','Phrases','Sentences','Story','Conversation'][stage]}</Text>
      {stage === 0 && (
        <FlatList data={lesson.words} keyExtractor={i=>i.id} renderItem={({item})=>(
          <TouchableOpacity style={styles.wordRow} onPress={()=>speak(item.text)}>
            <Image source={require('../../../assets/word-card.png')} style={{width:48,height:48,marginRight:10}} />
            <View style={{flex:1}}>
              <Text style={{fontSize:18,fontWeight:'800'}}>{item.text}</Text>
              <Text style={{color:'#555'}}>{item.meaning}</Text>
            </View>
          </TouchableOpacity>
        )} />
      )}
      <TouchableOpacity style={styles.nextBtn} onPress={async ()=>{
        if (stage < 4) setStage(s => s+1);
        else {
          await enqueueProgressUpload(profile.uid || 'anon', { lessonId: lesson.id, completedAt: Date.now() });
          Alert.alert('Great job!', 'Lesson completed 🎉');
          navigation.goBack();
        }
      }}>
        <Text style={{color:'#012'}}> {stage < 4 ? 'Next' : 'Finish'} </Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  wordRow:{backgroundColor:'#fff',padding:12,borderRadius:10,marginBottom:10,flexDirection:'row',alignItems:'center'},
  nextBtn:{backgroundColor:'#FFB703',padding:14,borderRadius:12,alignItems:'center',marginTop:12}
});
