import React from 'react';
import { View, Text, TouchableOpacity, Image, StyleSheet } from 'react-native';

export default function KidsHome({ navigation }) {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>Welcome to Kids Mode! 🎈</Text>
      <TouchableOpacity style={styles.card} onPress={() => navigation.navigate('KidsLesson', { lessonId: 'kiswahili_greetings_1' })}>
        <Text style={styles.cardText}>Words & Sounds</Text>
      </TouchableOpacity>
      <TouchableOpacity style={styles.card} onPress={() => navigation.navigate('StoryMode', { language: 'Kiswahili' })}>
        <Text style={styles.cardText}>Storytime</Text>
      </TouchableOpacity>
      <TouchableOpacity style={styles.card} onPress={() => navigation.navigate('Quiz', { questions: [] })}>
        <Text style={styles.cardText}>Quiz</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container:{flex:1, padding:20, backgroundColor:'#FFF8E7'},
  title:{fontSize:28, fontWeight:'900', color:'#023047', marginBottom:20},
  card:{backgroundColor:'#FFB703', padding:18, borderRadius:16, marginBottom:12},
  cardText:{fontSize:18, fontWeight:'800', color:'#012'},
});
