import React, {useState, useEffect} from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, FlatList, Alert } from 'react-native';
import { fetchLessonById } from '../../services/lessonService';
import { enqueueProgressUpload } from '../../services/offlineSync';
import { useProfileStore } from '../../store/profileStore';

export default function AdultLesson({ route, navigation }) {
  const lessonId = route.params?.lessonId || route.params?.lesson?.id;
  const [lesson, setLesson] = useState(null);
  const [stage, setStage] = useState(0);
  const [answer, setAnswer] = useState('');
  const profile = useProfileStore(s=>s.profile);

  useEffect(()=>{ async function l(){ const data = await fetchLessonById(lessonId); setLesson(data); } l(); },[]);

  if(!lesson) return <View><Text>Loading...</Text></View>;

  async function submit() {
    await enqueueProgressUpload(profile.uid || 'anon', { lessonId: lesson.id, stage, answer, ts: Date.now() });
    setAnswer('');
    if (stage < 4) setStage(s => s+1);
    else { Alert.alert('Completed','Lesson complete'); navigation.goBack(); }
  }

  return (
    <View style={{flex:1,padding:16,backgroundColor:'#F4FAFF'}}>
      <Text style={{fontSize:22,fontWeight:'900'}}>{lesson.topic}</Text>
      <Text style={{color:'#666',marginBottom:12}}>Stage: {['Words','Phrases','Sentences','Story','Conversation'][stage]}</Text>
      {stage===0 && <FlatList data={lesson.words} keyExtractor={i=>i.id} renderItem={({item})=>(
        <View style={{backgroundColor:'#fff',padding:12,borderRadius:10,marginBottom:10}}><Text style={{fontWeight:'800'}}>{item.text}</Text><Text style={{color:'#666'}}>{item.meaning}</Text></View>
      )} />}
      {stage===2 && (<><Text>Write a sentence using: {lesson.words?.[0]?.text}</Text><TextInput value={answer} onChangeText={setAnswer} style={styles.input}/></>)}
      <TouchableOpacity style={styles.btn} onPress={submit}><Text style={{color:'#fff'}}>{stage<4?'Submit':'Finish'}</Text></TouchableOpacity>
    </View>
  );
}

const styles=StyleSheet.create({ input:{backgroundColor:'#fff',padding:12,borderRadius:10,marginTop:8,marginBottom:12}, btn:{backgroundColor:'#005F73',padding:12,borderRadius:10,alignItems:'center',marginTop:10} });
