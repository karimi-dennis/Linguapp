import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';

export default function AdultHome({ navigation }) {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>Adult Learning Mode</Text>
      <TouchableOpacity style={styles.card} onPress={() => navigation.navigate('AdultLesson', { lessonId: 'kiswahili_greetings_1' })}>
        <Text style={styles.cardText}>Continue Lessons</Text>
      </TouchableOpacity>
      <TouchableOpacity style={styles.card} onPress={() => navigation.navigate('StoryMode', { language: 'Kiswahili' })}>
        <Text style={styles.cardText}>Cultural Stories</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container:{flex:1, padding:20, backgroundColor:'#F4FAFF'},
  title:{fontSize:24, fontWeight:'900', color:'#001219', marginBottom:20},
  card:{backgroundColor:'#fff', padding:16, borderRadius:12, marginBottom:12},
  cardText:{fontSize:18, fontWeight:'700', color:'#005F73'},
});
