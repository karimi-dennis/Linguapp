import React, { useEffect, useState } from 'react';
import { View, Text, ActivityIndicator } from 'react-native';
import { fetchLessonById, fetchLessonsFromFirestore } from '../services/lessonService';

export default function Lesson({ route, navigation }) {
  const lessonId = route.params?.lessonId || route.params?.lesson?.id;
  const [lesson, setLesson] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function load() {
      setLoading(true);
      const l = await fetchLessonById(lessonId);
      setLesson(l);
      setLoading(false);
    }
    load();
  }, [lessonId]);

  if (loading) return <ActivityIndicator style={{flex:1}} />;
  if (!lesson) return <View><Text>Lesson not found</Text></View>;

  return (
    <View style={{flex:1,padding:16}}>
      <Text style={{fontSize:20,fontWeight:'900'}}>{lesson.topic}</Text>
      <Text style={{color:'#666',marginTop:6}}>{lesson.description || ''}</Text>
    </View>
  );
}
