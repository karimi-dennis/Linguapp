import create from 'zustand';
import AsyncStorage from '@react-native-async-storage/async-storage';

export const useProfileStore = create((set, get) => ({
  profile: { ageGroup: 'Children (5-12)', interest: 'Animals 🦁', uid: null },
  xp: 0,
  badges: [],
  setProfile: async (p) => {
    set({ profile: {...get().profile, ...p} });
    await AsyncStorage.setItem('profile', JSON.stringify(get().profile));
  },
  addXP: async (n) => {
    set(state => ({ xp: state.xp + n }));
    await AsyncStorage.setItem('xp', String(get().xp));
  },
  addBadge: async (b) => {
    set(state => ({ badges: [...state.badges, b] }));
    await AsyncStorage.setItem('badges', JSON.stringify(get().badges));
  },
  load: async () => {
    const raw = await AsyncStorage.getItem('profile');
    if (raw) set({ profile: JSON.parse(raw) });
    const xp = await AsyncStorage.getItem('xp'); if (xp) set({ xp: Number(xp) });
    const badges = await AsyncStorage.getItem('badges'); if (badges) set({ badges: JSON.parse(badges) });
  }
}));
