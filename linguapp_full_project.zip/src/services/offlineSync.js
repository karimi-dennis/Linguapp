import AsyncStorage from '@react-native-async-storage/async-storage';
import * as FileSystem from 'expo-file-system';
import NetInfo from '@react-native-community/netinfo';
import { doc, setDoc } from 'firebase/firestore';
import { db } from '../firebaseConfig';

const PROGRESS_QUEUE_KEY = 'progress_upload_queue_v2';
const lessonsFolder = `${FileSystem.documentDirectory}lessons/`;

export async function cacheLessonJson(language, lesson) {
  try {
    await FileSystem.makeDirectoryAsync(lessonsFolder, { intermediates: true });
    const key = `${language}_${lesson.id}.json`;
    const path = `${lessonsFolder}${key}`;
    await FileSystem.writeAsStringAsync(path, JSON.stringify(lesson));
    return path;
  } catch(e){ console.warn('cacheLessonJson', e); return null; }
}

export async function getCachedLesson(language, lessonId) {
  try {
    const path = `${lessonsFolder}${language}_${lessonId}.json`;
    const info = await FileSystem.getInfoAsync(path);
    if (!info.exists) return null;
    const raw = await FileSystem.readAsStringAsync(path);
    return JSON.parse(raw);
  } catch(e){ return null; }
}

export async function enqueueProgressUpload(userId, payload) {
  const raw = await AsyncStorage.getItem(PROGRESS_QUEUE_KEY);
  const q = raw ? JSON.parse(raw) : [];
  q.push({ userId, payload, ts: Date.now() });
  await AsyncStorage.setItem(PROGRESS_QUEUE_KEY, JSON.stringify(q));
}

export async function flushProgressQueue() {
  const state = await NetInfo.fetch();
  if (!state.isConnected) return;
  const raw = await AsyncStorage.getItem(PROGRESS_QUEUE_KEY);
  const q = raw ? JSON.parse(raw) : [];
  const remaining = [];
  for (const job of q) {
    try {
      const ref = doc(db, 'users', job.userId, 'progress', job.payload.lessonId);
      await setDoc(ref, job.payload, { merge: true });
    } catch(e){ remaining.push(job); }
  }
  await AsyncStorage.setItem(PROGRESS_QUEUE_KEY, JSON.stringify(remaining));
}
