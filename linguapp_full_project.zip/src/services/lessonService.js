import { db } from '../firebaseConfig';
import { collection, query, where, getDocs, doc, getDoc } from 'firebase/firestore';
import AsyncStorage from '@react-native-async-storage/async-storage';

export async function fetchLessonsFromFirestore({ language='Kiswahili', ageGroup='Children (5-12)' }={}) {
  try {
    const colRef = collection(db, 'lessons');
    const q = query(colRef, where('language', '==', language));
    const snapshot = await getDocs(q);
    const lessons = [];
    snapshot.forEach(s => {
      const data = s.data();
      if (!data.ageGroups || data.ageGroups.includes(ageGroup)) lessons.push({ id: s.id, ...data });
    });
    await AsyncStorage.setItem(`lessons_cache:${language}:${ageGroup}`, JSON.stringify({ lessons, updatedAt:Date.now() }));
    return lessons;
  } catch(err) {
    console.warn('fetchLessons error', err);
    const raw = await AsyncStorage.getItem(`lessons_cache:${language}:${ageGroup}`);
    return raw ? JSON.parse(raw).lessons : [];
  }
}

export async function fetchLessonById(lessonId) {
  try {
    const ref = doc(db, 'lessons', lessonId);
    const snap = await getDoc(ref);
    return snap.exists() ? { id: snap.id, ...snap.data() } : null;
  } catch(e){ console.warn(e); return null; }
}
