import React, { useEffect } from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import KidsHome from './src/screens/kids/KidsHome';
import AdultHome from './src/screens/adult/AdultHome';
import Lesson from './src/screens/Lesson';
import KidsLesson from './src/screens/kids/KidsLesson';
import AdultLesson from './src/screens/adult/AdultLesson';
import StoryMode from './src/screens/StoryMode';
import ConversationMode from './src/screens/ConversationMode';
import Quiz from './src/screens/quiz/Quiz';
import { useProfileStore } from './src/store/profileStore';
import { flushProgressQueue } from './src/services/offlineSync';
import { initRevenueCat } from './src/utils/revenuecat';

const Stack = createStackNavigator();

export default function App() {
  const loadProfile = useProfileStore(s => s.load);

  useEffect(() => {
    loadProfile();
    flushProgressQueue();
    initRevenueCat && initRevenueCat();
  }, []);

  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="KidsHome" screenOptions={{ headerShown: true }}>
        <Stack.Screen name="KidsHome" component={KidsHome} />
        <Stack.Screen name="AdultHome" component={AdultHome} />
        <Stack.Screen name="Lesson" component={Lesson} />
        <Stack.Screen name="KidsLesson" component={KidsLesson} />
        <Stack.Screen name="AdultLesson" component={AdultLesson} />
        <Stack.Screen name="StoryMode" component={StoryMode} />
        <Stack.Screen name="ConversationMode" component={ConversationMode} />
        <Stack.Screen name="Quiz" component={Quiz} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}
