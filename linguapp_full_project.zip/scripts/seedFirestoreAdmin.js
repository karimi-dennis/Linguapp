const admin = require('firebase-admin');
const fs = require('fs');
const serviceAccountPath = './serviceAccount.json';
if (!fs.existsSync(serviceAccountPath)) {
  console.error('serviceAccount.json not found in scripts/. You must download it from Firebase Console and place it here.');
  process.exit(1);
}
const serviceAccount = require(serviceAccountPath);
admin.initializeApp({ credential: admin.credential.cert(serviceAccount) });
const db = admin.firestore();

const lessons = [
  {
    id: 'kiswahili_greetings_1',
    language: 'Kiswahili',
    topic: 'Greetings & Basics',
    level: 1,
    ageGroups: ['Children (5-12)','Youth (13-18)','Working Class (19+)'],
    words: [
      { id:'w1', text:'Jambo', meaning:'Hello', sample:'Jambo! Habari?' },
      { id:'w2', text:'Asante', meaning:'Thank you', sample:'Asante sana!' },
      { id:'w3', text:'Karibu', meaning:'Welcome', sample:'Karibu nyumbani.' },
      { id:'w4', text:'Chakula', meaning:'Food', sample:'Ninakula chakula.' },
      { id:'w5', text:'Maji', meaning:'Water', sample:'Naomba maji.' }
    ],
    phrases: ['Habari yako?','Jina lako nani?'],
    story: 'Palikuwa na mtoto mdogo aliyeenda sokoni...'
  },
  {
    id: 'english_greetings_1',
    language: 'English',
    topic: 'Greetings & Basics',
    level: 1,
    ageGroups: ['Children (5-12)','Youth (13-18)','Working Class (19+)'],
    words: [
      { id:'w1', text:'Hello', meaning:'Hello', sample:'Hello! How are you?' },
      { id:'w2', text:'Thank you', meaning:'Thank you', sample:'Thank you so much.' },
      { id:'w3', text:'Welcome', meaning:'Welcome', sample:'Welcome home.' },
      { id:'w4', text:'Food', meaning:'Food', sample:'I like food.' },
      { id:'w5', text:'Water', meaning:'Water', sample:'Can I have water?' }
    ],
    phrases: ['How are you?','What is your name?'],
    story: 'Once upon a time there was a little village...'
  },
  {
    id: 'spanish_greetings_1',
    language: 'Spanish',
    topic: 'Greetings & Basics',
    level:1,
    ageGroups: ['Children (5-12)','Youth (13-18)','Working Class (19+)'],
    words:[
      {id:'w1', text:'Hola', meaning:'Hello', sample:'Hola! ¿Cómo estás?'},
      {id:'w2', text:'Gracias', meaning:'Thank you', sample:'Gracias por todo.'},
      {id:'w3', text:'Bienvenido', meaning:'Welcome', sample:'Bienvenido a casa.'},
      {id:'w4', text:'Comida', meaning:'Food', sample:'Me gusta la comida.'},
      {id:'w5', text:'Agua', meaning:'Water', sample:'¿Puedo tener agua?'}
    ],
    phrases:['¿Cómo estás?','¿Cómo te llamas?'],
    story:'Había una vez un pequeño pueblo...'
  },
  {
    id: 'chinese_greetings_1',
    language: 'Chinese',
    topic: 'Greetings & Basics',
    level:1,
    ageGroups: ['Children (5-12)','Youth (13-18)','Working Class (19+)'],
    words:[
      {id:'w1', text:'你好', meaning:'Hello', sample:'你好! 你好吗?'},
      {id:'w2', text:'谢谢', meaning:'Thank you', sample:'非常感谢.'},
      {id:'w3', text:'欢迎', meaning:'Welcome', sample:'欢迎回家.'},
      {id:'w4', text:'食物', meaning:'Food', sample:'我喜欢食物.'},
      {id:'w5', text:'水', meaning:'Water', sample:'我可以要水吗?'}
    ],
    phrases:['你好吗?','你叫什么名字?'],
    story:'从前在一个小村庄里...'
  },
  {
    id: 'french_greetings_1',
    language: 'French',
    topic: 'Greetings & Basics',
    level:1,
    ageGroups: ['Children (5-12)','Youth (13-18)','Working Class (19+)'],
    words:[
      {id:'w1', text:'Bonjour', meaning:'Hello', sample:'Bonjour! Comment ça va?'},
      {id:'w2', text:'Merci', meaning:'Thank you', sample:'Merci beaucoup.'},
      {id:'w3', text:'Bienvenue', meaning:'Welcome', sample:'Bienvenue chez vous.'},
      {id:'w4', text:'Nourriture', meaning:'Food', sample:'J'aime la nourriture.'},
      {id:'w5', text:'Eau', meaning:'Water', sample:'Puis-je avoir de l\'eau?'}
    ],
    phrases:['Comment ça va?','Comment tu t'appelles?'],
    story:'Il était une fois un petit village...'
  }
];

async function seed() {
  for (const lesson of lessons) {
    await db.collection('lessons').doc(lesson.id).set(lesson);
    console.log('seeded', lesson.id);
  }
  console.log('Seeding finished.');
  process.exit(0);
}

seed().catch(e=>{ console.error(e); process.exit(1); });
